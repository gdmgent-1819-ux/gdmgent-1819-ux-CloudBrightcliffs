# Eindopdracht UX

- Voornaam: Eveline
- Familienaam: Bonte
- Studentnummer: 104805
- Klasgroep: 1MMPa
- UX prototype link: https://xd.adobe.com/view/e7808866-507f-4d4a-549c-fa6a513a900d-91b1/ 
